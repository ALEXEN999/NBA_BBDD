package BBDD;

import com.mysql.cj.protocol.Resultset;

import java.sql.*;
import java.util.Scanner;

public class App 
{
    public App() {}

    public Connection getConnection() {
        Connection connection = null;
        String nombre= null;
        String cognom = null;
        Scanner in = new Scanner(System.in);
        try {
            connection = DriverManager.getConnection("jdbc:mysql://192.168.22.215:3306/alejandroPereiraEscola","root","#Password0");
            System.out.println("BBD CONNECTED");

            //Creem un objecte Statement
            Statement st = connection.createStatement();

            //Consultem les dades de tots els usuaris
            ResultSet rs = st.executeQuery("SELECT * FROM alumnes");
            while (rs.next()) System.out.println(rs.getString("nombre")+"--"+rs.getString("edad"));

            System.out.println("Escribe el nombre del nuevo alumne: ");

            nombre = in.nextLine();

            System.out.println("Escribe el nombre del nuevo alumne: ");

            cognom = in.nextLine();


            st.executeUpdate("INSERT INTO alumnes "+ "(nombre,cognom,edad,institut) VALUES "+"('"+nombre+"','"+cognom+"','"+38+"','El Puig')");

            ResultSet rsEdad = st.executeQuery("SELECT * FROM alumnes WHERE edad >=25 AND edad <=48");
            while (rsEdad.next()) System.out.println(rsEdad.getString("nombre")+"-->"+rsEdad.getString("cognom")+"-->"+rsEdad.getString("edad")+"-->"+rsEdad.getString("institut"));

            //tanquem el ResultSet, Statement i Connection.
            rs.close();
            st.close();
            rsEdad.close();
            connection.close();

        }catch (SQLException e ){
            System.out.println(e);
        }
        return connection;
    }

    public static void main(String[] args) {
        App app  = new App();
        Connection connection = app.getConnection();
    }

}
